var api = typeof browser !== "undefined" ? browser : chrome;
var go = document.getElementById("go");
var msg = document.getElementById("msg");

go.addEventListener("click", function () {
  go.disabled = true;
  msg.textContent = "";

  api.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    return api.tabs.sendMessage(tabs[0].id, { type: "PURGE" });
  }).then(function (res) {
    msg.textContent = res.removed > 0 ? "removed " + res.removed : "none found";
  }).catch(function () {
    msg.textContent = "refresh page first";
  }).then(function () {
    go.disabled = false;
  });
});
