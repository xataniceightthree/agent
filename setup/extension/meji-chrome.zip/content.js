(function () {
  "use strict";

  var api = chrome;
  var FLAG = "meji_modal_purged";
  var loadId = Date.now() + ":" + Math.random().toString(36).slice(2);

  function purge() {
    var hits = 0;

    document.querySelectorAll('[data-ruic="Modal"]').forEach(function (el) {
      el.remove();
      hits++;
    });

    document.querySelectorAll("div[style]").forEach(function (el) {
      var style = el.getAttribute("style") || "";
      if (style.indexOf("max-width: 480px") !== -1 && style.indexOf("box-shadow") !== -1) {
        el.remove();
        hits++;
      }
    });

    document.querySelectorAll("h1").forEach(function (h) {
      if (h.textContent.trim() !== "Let's set up your account") return;
      var box = h.closest("div[class]");
      while (box && !box.querySelector("form")) {
        box = box.parentElement;
      }
      if (box) {
        box.remove();
        hits++;
      }
    });

    if (hits > 0) {
      document.documentElement.style.overflow = "";
      if (document.body) document.body.style.overflow = "";
    }

    return hits;
  }

  function autoRun() {
    api.storage.local.get(FLAG).then(function (res) {
      if (res && res[FLAG] === loadId) return;
      api.storage.local.set({ [FLAG]: loadId });

      var tries = 0;
      var timer = setInterval(function () {
        tries++;
        var hits = purge();
        if (hits > 0 || tries >= 15) clearInterval(timer);
      }, 500);
    }).catch(function () {
      purge();
    });
  }

  api.runtime.onMessage.addListener(function (msg, sender, reply) {
    if (msg && msg.type === "PURGE") {
      reply({ removed: purge() });
    }
    return false;
  });

  autoRun();
})();
